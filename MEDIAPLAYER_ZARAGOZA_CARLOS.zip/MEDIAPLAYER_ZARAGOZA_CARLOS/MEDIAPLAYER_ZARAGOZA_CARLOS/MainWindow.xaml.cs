﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MEDIAPLAYER_ZARAGOZA_CARLOS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private Cancion current_song = null;
        private DirectoryInfo _directory;
        List<Cancion> lista_canciones = new List<Cancion>();
        public MainWindow()
        {
            InitializeComponent();

            GetSongs("C:/WINDOWS/MEDIA/");
            lista.ItemsSource = lista_canciones;
        }


        public void GetSongs(string ruta)
        {
          

            _directory = new DirectoryInfo(ruta);
            foreach (var f in _directory.GetFiles("*.wav"))
            {
                lista_canciones.Add(new Cancion()
                {
                    ruta = f.FullName,
                    tamanio = f.Length,
                    name = f.Name
                });
            }
        }

        private void mode_Click(object sender, RoutedEventArgs e)
        {
            if (mode.IsChecked == true)
            {
                mode.Content = "Dark Mode".ToUpper();
                mode.Foreground = new SolidColorBrush(Colors.White);
                MAIN.Style = (Style)Resources["black"];
                Current_State.Style = (Style)Resources["crtStateBlack"];
            }
            if (mode.IsChecked == false)
            {
                mode.Content = "Light Mode".ToUpper();
                mode.Foreground = new SolidColorBrush(Colors.Black);
                MAIN.Style = (Style)Resources["white"];
                Current_State.Style = (Style)Resources["crtStateWhite"];
                

            }
        }

    

        private void lista_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lista.SelectedItem != null)
            {
                current_song = lista.SelectedItem as Cancion;
                selected_song.Text = current_song.name;
            }
        }

   

        private void btnPlay_Click(object sender, RoutedEventArgs e)
        {
            if (current_song != null)
            {
                media_element.Source = new Uri(current_song.ruta);
                Current_State.Text = "Reproduciendo";
                media_element.Play();
            }
            else
            {
                MessageBox.Show("Seleccione una cancion");
            }
        }

        private void btnReset_Cick(object sender, RoutedEventArgs e)
        {
            current_song = null;
            Current_State.Text = "";
            media_element.Pause();
            media_element.Source = null;
            MessageBox.Show("Reproductor Reseteado");
            selected_song.Text = "";
        }

        private void btnPause_Click(object sender, RoutedEventArgs e)
        {
            if (current_song != null && Current_State.Text.Equals("Reproduciendo"))
            {
                Current_State.Text = "PAUSADA";
                media_element.Pause();
            }
            else
            {
                MessageBox.Show("REPRODUZCA UNA CANCION");
            }
        }
    }
}

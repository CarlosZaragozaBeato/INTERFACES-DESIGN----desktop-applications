﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MEDIAPLAYER_ZARAGOZA_CARLOS
{
    class Cancion
    {
        public string ruta { get; set; }
        public long tamanio { get; set; }
        public string name { get; set; }
    }
}
